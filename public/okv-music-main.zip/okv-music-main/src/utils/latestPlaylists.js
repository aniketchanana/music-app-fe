export const latestPlaylists = [
  { title: "New Released", id: "RDCLAK5uy_ksEjgm3H_7zOJ_RHzRjN1wY-_FFcs7aAU" },
  {
    title: "New Music Hindi",
    id: "RDCLAK5uy_nNhhgRET3NcJ4SJBvqhAIJ6t7vjsQYowc",
  },
  {
    title: "New Indian Pop",
    id: "RDCLAK5uy_k66J6mE65JgdE4zoeNSzmw_16JB_ueINE",
  },
  {
    title: "New Music Panjab",
    id: "RDCLAK5uy_mk3xwsayv9PxawuXS-U6ao9eMeNmSwYAM",
  },
  {
    title: "New Music Haryanvi",
    id: "RDCLAK5uy_nTkyDVpCk3iCQG_3bDJyhGgb1uzcBZM4A",
  },
  {
    title: "New Music Telgu",
    id: "RDCLAK5uy_l8CaYQvBQWVT2st1VsW9JjODWisR_vd3U",
  },
  {
    title: "New Music Tamil",
    id: "RDCLAK5uy_nVQAtE2KBWk-ROQIc5o39Oup3hOLnYV0g",
  },
];
